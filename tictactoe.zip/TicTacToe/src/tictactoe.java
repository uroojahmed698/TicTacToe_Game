import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class tictactoe {

	private JFrame frame;
	private JTextField xCount;
	private JTextField oCount;
	private int xScore = 0;
	private int oScore = 0;
	private String startGame = "X";
	private int b1 = 10;
	private int b2 = 10;
	private int b3 = 10;
	private int b4 = 10;
	private int b5 = 10;
	private int b6 = 10;
	private int b7 = 10;
	private int b8 = 10;
	private int b9 = 10;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tictactoe window = new tictactoe();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public tictactoe() {
		initialize();
	}
	
	private void winner() {
		if((b1==1 && b2==1 && b3==1)||(b4==1 && b5==1 && b6==1)||(b7==1 && b8==1 && b9==1)||(b1==1&&b4==1&&b7==1)||(b2==1&&b5==1&&b8==1)||(b3==1&&b6==1&&b9==1)||(b1==1&&b5==1&&b9==1)||(b3==1&&b5==1&&b7==1)) {
			JOptionPane.showMessageDialog(frame, "Player X Wins", "Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
			xScore++;
			xCount.setText(String.valueOf(xScore));
		}
		else if((b1==0 && b2==0 && b3==0)||(b4==0 && b5==0 && b6==0)||(b7==0 && b8==0 && b9==0)||(b1==0&&b4==0&&b7==0)||(b2==0&&b5==0&&b8==0)||(b3==0&&b6==0&&b9==0)||(b1==0&&b5==0&&b9==0)||(b3==0&&b5==0&&b7==0)){
			JOptionPane.showMessageDialog(frame, "Player O Wins", "Tic Tac Toe",JOptionPane.INFORMATION_MESSAGE);
			oScore++;
			oCount.setText(String.valueOf(oScore));
		}
	}
	
	public void choosePlayer() {
		if(startGame.equals("X")) {
			startGame = "O";

		}
		else {
			startGame = "X";


		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(3, 5, 2, 2));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JButton btnOne = new JButton("");
		btnOne.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnOne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnOne.setText(startGame);
				if(startGame.equals("X")) {
					btnOne.setForeground(Color.RED);
					b1 = 1;
				}
				else {
					btnOne.setForeground(Color.BLUE);
					b1 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		panel_1.add(btnOne, BorderLayout.CENTER);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_2);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		JButton btnTwo = new JButton("");
		btnTwo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnTwo.setText(startGame);
				if(startGame.equals("X")) {
					btnTwo.setForeground(Color.RED);
					b2 = 1;
				}
				else {
					btnTwo.setForeground(Color.BLUE);
					b2 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		btnTwo.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel_2.add(btnTwo, BorderLayout.CENTER);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_3);
		panel_3.setLayout(new BorderLayout(0, 0));
		
		JButton btnThree = new JButton("");
		btnThree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnThree.setText(startGame);
				if(startGame.equals("X")) {
					btnThree.setForeground(Color.RED);
					b3 = 1;
				}
				else {
					btnThree.setForeground(Color.BLUE);
					b3 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		btnThree.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel_3.add(btnThree, BorderLayout.CENTER);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_4);
		panel_4.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("Player X");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		panel_4.add(lblNewLabel, BorderLayout.CENTER);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_5);
		panel_5.setLayout(new BorderLayout(0, 0));
		
		xCount = new JTextField();
		xCount.setHorizontalAlignment(SwingConstants.CENTER);
		xCount.setFont(new Font("Tahoma", Font.BOLD, 16));
		xCount.setText("0");
		panel_5.add(xCount, BorderLayout.CENTER);
		xCount.setColumns(10);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_6);
		panel_6.setLayout(new BorderLayout(0, 0));
		
		JButton btnFour = new JButton("");
		btnFour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnFour.setText(startGame);
				if(startGame.equals("X")) {
					btnFour.setForeground(Color.RED);
					b4 = 1;
				}
				else {
					btnFour.setForeground(Color.BLUE);
					b4 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		btnFour.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel_6.add(btnFour, BorderLayout.CENTER);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_7);
		panel_7.setLayout(new BorderLayout(0, 0));
		
		JButton btnFive = new JButton("");
		btnFive.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnFive.setText(startGame);
				if(startGame.equals("X")) {
					btnFive.setForeground(Color.RED);
					b5 = 1;
				}
				else {
					btnFive.setForeground(Color.BLUE);
					b5 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		btnFive.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel_7.add(btnFive, BorderLayout.CENTER);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_8);
		panel_8.setLayout(new BorderLayout(0, 0));
		
		JButton btnSix = new JButton("");
		btnSix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnSix.setText(startGame);
				if(startGame.equals("X")) {
					btnSix.setForeground(Color.RED);
					b6 = 1;
				}
				else {
					btnSix.setForeground(Color.BLUE);
					b6 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		btnSix.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel_8.add(btnSix, BorderLayout.CENTER);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_9);
		panel_9.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel_1 = new JLabel("Player O");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 24));
		panel_9.add(lblNewLabel_1, BorderLayout.CENTER);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_10);
		panel_10.setLayout(new BorderLayout(0, 0));
		
		oCount = new JTextField();
		oCount.setHorizontalAlignment(SwingConstants.CENTER);
		oCount.setText("0");
		oCount.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel_10.add(oCount, BorderLayout.CENTER);
		oCount.setColumns(10);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_11);
		panel_11.setLayout(new BorderLayout(0, 0));
		
		JButton btnSeven = new JButton("");
		btnSeven.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnSeven.setText(startGame);
				if(startGame.equals("X")) {
					btnSeven.setForeground(Color.RED);
					b7 = 1;
				}
				else {
					btnSeven.setForeground(Color.BLUE);
					b7 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		btnSeven.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel_11.add(btnSeven, BorderLayout.CENTER);
		
		JPanel panel_12 = new JPanel();
		panel_12.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_12);
		panel_12.setLayout(new BorderLayout(0, 0));
		
		JButton btnEight = new JButton("");
		btnEight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnEight.setText(startGame);
				if(startGame.equals("X")) {
					btnEight.setForeground(Color.RED);
					b8 = 1;
				}
				else {
					btnEight.setForeground(Color.BLUE);
					b8 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		btnEight.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel_12.add(btnEight, BorderLayout.CENTER);
		
		JPanel panel_13 = new JPanel();
		panel_13.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_13);
		panel_13.setLayout(new BorderLayout(0, 0));
		
		JButton btnNine = new JButton("");
		btnNine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNine.setText(startGame);
				if(startGame.equals("X")) {
					btnNine.setForeground(Color.RED);
					b9 = 1;
				}
				else {
					btnNine.setForeground(Color.BLUE);
					b9 = 0;
				}
				choosePlayer();
				winner();
			}
		});
		btnNine.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel_13.add(btnNine, BorderLayout.CENTER);
		
		JPanel panel_14 = new JPanel();
		panel_14.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_14);
		panel_14.setLayout(new BorderLayout(0, 0));
		
		JButton resetBtn = new JButton("RESET");
		resetBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnOne.setText(null);
				btnTwo.setText(null);
				btnThree.setText(null);
				btnFour.setText(null);
				btnFive.setText(null);
				btnSix.setText(null);
				btnSeven.setText(null);
				btnEight.setText(null);
				btnNine.setText(null);
				b1 = 10;
				b2 = 10;
				b3 = 10;
				b4 = 10;
				b5 = 10;
				b6 = 10;
				b7 = 10;
				b8 = 10;
				b9 = 10;
				if(startGame.equals("X")) {
					JOptionPane.showMessageDialog(frame, "X's Turn", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);

				}
				else {
					JOptionPane.showMessageDialog(frame, "O's Turn", "Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);


				}
				}
		});
		resetBtn.setFont(new Font("Bookman Old Style", Font.PLAIN, 24));
		panel_14.add(resetBtn, BorderLayout.CENTER);
		
		JPanel panel_15 = new JPanel();
		panel_15.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.add(panel_15);
		panel_15.setLayout(new BorderLayout(0, 0));
		
		JButton exitBtn = new JButton("EXIT");
		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame, "Would you like to exit?", "Tic Tac Toe", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		exitBtn.setFont(new Font("Bookman Old Style", Font.PLAIN, 24));
		panel_15.add(exitBtn, BorderLayout.CENTER);
	}

}
